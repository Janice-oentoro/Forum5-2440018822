<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Student List GPA')</title>
</head>
<body>
<h1>Student List GPA</h1>
    <p>Simple student database</p>
    <br>
        <p>Select action</p>
        <a href="/create">Add Student</a>
        <a href="/list">View Students</a>
</body>
</html>