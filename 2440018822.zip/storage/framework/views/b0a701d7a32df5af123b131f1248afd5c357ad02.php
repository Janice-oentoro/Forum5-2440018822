<div class="footer">
    <br>
    Forum GSLC WebProg - 2440018822
</div><?php /**PATH C:\Users\Janice\Downloads\Forum_GSLC\resources\views/footer.blade.php ENDPATH**/ ?>